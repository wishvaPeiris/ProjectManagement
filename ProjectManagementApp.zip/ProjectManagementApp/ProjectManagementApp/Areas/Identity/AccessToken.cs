﻿namespace ProjectManagementApp.Areas.Identity
{
    public class AccessToken
    {
        public string XsrfToken { get; set; }
        public string RefreshToken { get; set; }
    }
}
